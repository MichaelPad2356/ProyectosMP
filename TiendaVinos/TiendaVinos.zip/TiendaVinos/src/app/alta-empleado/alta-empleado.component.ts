import { Component } from '@angular/core';

@Component({
  selector: 'app-alta-empleado',
  standalone: true,
  imports: [],
  templateUrl: './alta-empleado.component.html',
  styleUrl: './alta-empleado.component.css'
})
export class AltaEmpleadoComponent {

}
