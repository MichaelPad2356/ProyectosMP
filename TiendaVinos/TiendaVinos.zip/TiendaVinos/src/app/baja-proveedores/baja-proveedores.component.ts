import { Component } from '@angular/core';

@Component({
  selector: 'app-baja-proveedores',
  standalone: true,
  imports: [],
  templateUrl: './baja-proveedores.component.html',
  styleUrl: './baja-proveedores.component.css'
})
export class BajaProveedoresComponent {

}
