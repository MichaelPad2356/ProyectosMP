import { Component } from '@angular/core';

@Component({
  selector: 'app-alta-producto',
  standalone: true,
  imports: [],
  templateUrl: './alta-producto.component.html',
  styleUrl: './alta-producto.component.css'
})
export class AltaProductoComponent {

}
