import { Component } from '@angular/core';

@Component({
  selector: 'app-alta-proveedores',
  standalone: true,
  imports: [],
  templateUrl: './alta-proveedores.component.html',
  styleUrl: './alta-proveedores.component.css'
})
export class AltaProveedoresComponent {

}
