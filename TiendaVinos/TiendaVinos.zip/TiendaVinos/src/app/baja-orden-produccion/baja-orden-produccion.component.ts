import { Component } from '@angular/core';

@Component({
  selector: 'app-baja-orden-produccion',
  standalone: true,
  imports: [],
  templateUrl: './baja-orden-produccion.component.html',
  styleUrl: './baja-orden-produccion.component.css'
})
export class BajaOrdenProduccionComponent {

}
