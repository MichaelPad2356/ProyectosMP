import { Component } from '@angular/core';

@Component({
  selector: 'app-alta-orden-produccion',
  standalone: true,
  imports: [],
  templateUrl: './alta-orden-produccion.component.html',
  styleUrl: './alta-orden-produccion.component.css'
})
export class AltaOrdenProduccionComponent {

}
