import { Component } from '@angular/core';

@Component({
  selector: 'app-baja-producto',
  standalone: true,
  imports: [],
  templateUrl: './baja-producto.component.html',
  styleUrl: './baja-producto.component.css'
})
export class BajaProductoComponent {

}
