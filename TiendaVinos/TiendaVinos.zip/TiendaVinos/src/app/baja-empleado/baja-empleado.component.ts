import { Component } from '@angular/core';

@Component({
  selector: 'app-baja-empleado',
  standalone: true,
  imports: [],
  templateUrl: './baja-empleado.component.html',
  styleUrl: './baja-empleado.component.css'
})
export class BajaEmpleadoComponent {

}
